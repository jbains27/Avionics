ATA Specification 2000 

Revision 2009.1

---------------------------------------------------------------------------------------------------------
	Limitations of Liability:
	
 1.  This material is provided "As Is" and neither ATA nor any person who has contributed to the creation, revision or maintenance of the material makes any representations or warranties, express or implied, including but not limited to, warranties of merchantability or fitness for any particular purpose.

2.  Neither ATA nor any person who has contributed to the creation, revision or maintenance of this material shall be liable for any direct, indirect, special or consequential damages or any other liability arising from any use of this material.

3.  Revisions to this document may occur after its issuance.  The user is responsible for determining if revisions to the material contained in this document have occurred and are applicable.  
---------------------------------------------------------------------------------------------------------

The purpose of this Readme file is to describe the contents and use of the ATA Spec 2000 files.

The ATA_Spec2000_2009.1 zip file contains the following:

* S2K_Ch16_2009.1.pdf - This is the complete ATA Spec 2000 Chapter 16 document, version 2009.1.  This includes descriptions of the relevant XML Schema files, as well as an appendix containing an extract from the ATA Common Support Data Dictionary (CSDD) for all elements and attributes used in the message/file Schemas.

*  A subfolder entitled "ModularSchema" - This subfolder contains the following related XML Schema files needed to create and/or validate various messages or exchange files as described in the specification.  

Common XML Schema:
* ATA_InformationSet.xsd
* ATA_CommonTypes.xsd
* CSDD_MM.xsd
* MM_CommonTypes.xsd
* Reliability_CommonTypes.xsd
* ATA_DSE_Logbook_CommonTypes.xsd
* W3C_XML_Signature.xsd

Individual Message or File XML Schema. Note that most of these use an XML �include� statement for one or more of the above Common Schema:
* AircraftEvent.xsd
* AircraftHoursAndLandings.xsd
* AircraftStatusChange.xsd
* ATA_DSE_Logbook_v2.02.xsd
* ATA_InvoiceMessageAck.xsd
* ATA_PartCertificationForm.xsd
* ATA_SparesInvoice.xsd
* ATA_SparesMessageAck.xsd
* ATA_SparesOrder.xsd
* ATA_SparesOrderBookback.xsd
* ATA_SparesOrderExc.xsd
* ATA_SparesOrderStatusInquiry.xsd
* ATA_SparesOrderStatusResponse.xsd
* ATA_SparesQuoteFinal.xsd
* ATA_SparesQuoteInterim.xsd
* ATA_SparesQuoteRequest.xsd
* ATA_SparesStockInquiry.xsd
* ATA_SparesStockResponse.xsd
* ATA_SparesSupplierShipNotice.xsd
* DraftTeardown.xsd
* Logbook.xsd
* LRU_Removal.xsd
* PieceParts.xsd"
* ScheduledMaintenance.xsd
* ServiceBulletin.xsd
* ShopFindings.xsd
* SummaryData.xsd


All of these files should be stored in the same file directory.  The main, or root, schema file is "ATA_InformationSet.xsd." Note that to be used, ATA_InformationSet must be edited and �comment� markers removed according to the applicable message/file schema that is desired. See Spec 2000 Appendix 10 for more information. 

*  A subfolder entitled "FlatSchema" - This subfolder contains the following files:

* AircraftEvent.xsd
* AircraftHoursAndLandings.xsd
* AircraftStatusChange.xsd
* ATA_DSE_Logbook_v2.02.xsd
* ATA_InformationSet.xsd
* ATA_InvoiceMessageAck.xsd
* ATA_PartCertificationForm.xsd
* ATA_SparesInvoice.xsd
* ATA_SparesMessageAck.xsd
* ATA_SparesOrder.xsd
* ATA_SparesOrderBookback.xsd
* ATA_SparesOrderExc.xsd
* ATA_SparesOrderStatusInquiry.xsd
* ATA_SparesOrderStatusResponse.xsd
* ATA_SparesQuoteFinal.xsd
* ATA_SparesQuoteInterim.xsd
* ATA_SparesQuoteRequest.xsd
* ATA_SparesStockInquiry.xsd
* ATA_SparesStockResponse.xsd
* ATA_SparesSupplierShipNotice.xsd
* DraftTeardown.xsd
* Logbook.xsd
* LRU_Removal.xsd
* PieceParts.xsd"
* ScheduledMaintenance.xsd
* ServiceBulletin.xsd
* ShopFindings.xsd
* SummaryData.xsd

Each of these are �flat� XML Schema that have effectively included all XML structure to validate an individual message. Note that ATA_DSE_Logbook is not included. 


