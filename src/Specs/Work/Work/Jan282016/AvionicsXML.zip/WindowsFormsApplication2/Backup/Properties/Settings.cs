﻿// Decompiled with JetBrains decompiler
// Type: WindowsFormsApplication2.Properties.Settings
// Assembly: WindowsFormsApplication2, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: F26F28AE-C020-4D78-9CDC-CDBBF01F0617
// Assembly location: C:\Users\Sumit\Desktop\Please change the extension to .exe from .exe1 (1)\WindowsFormsApplication2.exe

using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace WindowsFormsApplication2.Properties
{
  [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "9.0.0.0")]
  [CompilerGenerated]
  internal sealed class Settings : ApplicationSettingsBase
  {
    private static Settings defaultInstance = (Settings) SettingsBase.Synchronized((SettingsBase) new Settings());

    public static Settings Default
    {
      get
      {
        return Settings.defaultInstance;
      }
    }
  }
}
